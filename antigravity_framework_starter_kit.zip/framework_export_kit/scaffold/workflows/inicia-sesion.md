---
description: Sincroniza el contexto y verifica el entorno antes de empezar.
agent: Senior Architect
skills: [project-context]
---
# Workflow: Inicio de Sesión (Template)

1. **Contexto**: `cat .agent/next_steps.md`
2. **Dependencias**: Instalar/Actualizar entorno.
3. **Salud**: Correr tests rápidos.

## Resultado Esperado
- Entorno listo y meta de la sesión clara.
