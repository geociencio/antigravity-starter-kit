---
description: Documenta logros y prepara el paso de testigo.
agent: Technical Lead
skills: [coding-standards]
---
# Workflow: Cierre de Sesión (Template)

1. **Validación**: Correr tests finales.
2. **Memoria**: Actualizar `AGENT_LESSONS.md` y `next_steps.md`.
3. **Git**: Git add y commit siguiendo estándares.

## Resultado Esperado
- Trabajo persistido y guía para la siguiente sesión.
